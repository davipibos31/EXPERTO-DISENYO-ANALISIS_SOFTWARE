package Visitor01;
public interface IPersonaje
{
     public void accept( IVisitor visitor );
}