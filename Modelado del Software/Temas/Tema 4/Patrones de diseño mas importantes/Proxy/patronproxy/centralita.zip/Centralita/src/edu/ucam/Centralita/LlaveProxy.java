package edu.ucam.Centralita;

public class LlaveProxy extends Llave{
	
	// Referencia a la llave original
    private Llave llaveOriginal;
 
    // Constructor en el que se inyectar� el objeto real
    public LlaveProxy(Llave llave)
    {
        llaveOriginal = llave;
    }
 
    // Este m�todo realizar� el control de acceso sobre el m�todo original.
    // Realizar� una comprobaci�n previa comparando el c�digo de seguridad y, si este es
    // correcto, invocar� el m�todo del objeto real.
    @Override
    public void RealizarContacto(CentralitaVehiculo centralita)
    {
        // Realizamos una comprobaci�n adicional de seguridad. En caso de no cumplirse, se
        // aborta la operaci�n. Esta operaci�n podr�a ser la ejecuci�n de un algoritmo para
        // comprobar la autenticidad del c�digo de la llave, una comprobaci�n de nombre de
        // usuario y contrase�a... o cualquier otra comprobaci�n que queramos realizar.
        if (centralita.getCodigoSeguridad() > llaveOriginal.getCodigoLlave()) {
            System.out.println("C�digo de seguridad incorrecto. Abortanto arranque");
            return;
        }
 
        if (LlaveCorrecta(centralita.getCodigoLlave()))
        	System.out.println("Contacto realizado");
        else
        	System.out.println("C�digo de llave inv�lido");
    }
 
    // Este m�todo no realizar� comprobaciones adicionales. Se limitar� a invocar el m�todo
    // del objeto real.
    @Override
    public Boolean LlaveCorrecta(int codigoLlave)
    {
        return llaveOriginal.LlaveCorrecta(codigoLlave);
    }
}
