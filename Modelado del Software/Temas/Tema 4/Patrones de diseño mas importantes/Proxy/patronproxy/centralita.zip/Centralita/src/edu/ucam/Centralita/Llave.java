package edu.ucam.Centralita;

public abstract class Llave {
	
	// clase abstracta de la que heredar� el elemento original y el proxy
		// C�digo de la llave
		protected int codigoLlave;
		
		//proiedad de s�lo lectura para obtener el c�digo de la llave
		public int getCodigoLlave() {
			return codigoLlave;
		}
		
		// m�todos abstractos que implementar�n el elemento real y el proxy
		public abstract void RealizarContacto(CentralitaVehiculo centralita);
	    public abstract Boolean LlaveCorrecta(int codigoLlave);

}
