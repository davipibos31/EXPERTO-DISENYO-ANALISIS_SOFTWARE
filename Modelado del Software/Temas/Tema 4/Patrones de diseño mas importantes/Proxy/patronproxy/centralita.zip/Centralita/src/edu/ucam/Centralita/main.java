package edu.ucam.Centralita;

public class main {

	public static void main(String[] args) {
		int codigoLlave = 532543463;
		int codigoSeguridad = 1038948470;
		 
		CentralitaVehiculo centralita = new CentralitaVehiculo(codigoLlave, codigoSeguridad);
		 
		Llave llaveSimple = new LlaveReal(codigoLlave);
		llaveSimple.RealizarContacto(centralita);
		 
		Llave proxy = new LlaveProxy(llaveSimple);
		proxy.RealizarContacto(centralita);
		
		codigoLlave = 532543463;
		codigoSeguridad = -1098948470;
		 
		CentralitaVehiculo centralitaAG = new CentralitaVehiculo(codigoLlave, codigoSeguridad);
		 
		llaveSimple = new LlaveReal(codigoLlave);
		llaveSimple.RealizarContacto(centralitaAG);
		 
		proxy = new LlaveProxy(llaveSimple);
		proxy.RealizarContacto(centralitaAG);
	}

}
