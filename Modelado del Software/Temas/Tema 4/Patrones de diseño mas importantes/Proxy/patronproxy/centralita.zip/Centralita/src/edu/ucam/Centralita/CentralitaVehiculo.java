package edu.ucam.Centralita;

public class CentralitaVehiculo {
	
	private int codigoLlave;
	private int codigoSeguridad;
	
	public CentralitaVehiculo(int codigoLlave, int codigoSeguridad) {
		this.codigoLlave = codigoLlave;
		this.codigoSeguridad = codigoSeguridad;
	}

	public int getCodigoLlave() {
		return codigoLlave;
	}

	public int getCodigoSeguridad() {
		return codigoSeguridad;
	}	

}
