package edu.ucam.Centralita;

public class LlaveReal extends Llave {
	
	// Constructor base: asigna el c�digo de la llave a la llave
	public LlaveReal(int codigoLlave) {		
		this.codigoLlave = codigoLlave;
	}
	
	//Realizar contacto: comprueba que el c�digo de la llave sea correcto
	//en caso de que lo sea, arranca el veh�culo
	@Override
	public void RealizarContacto(CentralitaVehiculo centralita)
    {
        if (LlaveCorrecta(centralita.getCodigoLlave()))
            System.out.println("Contacto realizado");
        else
        	System.out.println("C�digo de llave inv�lido");
    }
	
	//Comprueba que el c�digo proporciona coincide con el de la llave
	@Override
	public Boolean LlaveCorrecta(int codigoLlave) {
		return codigoLlave == this.codigoLlave;
	}

}