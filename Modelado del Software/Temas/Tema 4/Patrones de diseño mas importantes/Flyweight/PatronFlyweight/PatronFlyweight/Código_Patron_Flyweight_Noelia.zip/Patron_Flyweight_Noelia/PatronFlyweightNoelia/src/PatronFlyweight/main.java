package PatronFlyweight;

import java.sql.Date;

public class main {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Creamos un nuevo FactoryFlyweight.
		FactoryFlyweight fflyweight = new FactoryFlyweight();
		
		//Listado de marcas
		String marca[] = {"Mazda", "Mazda", "Ford", "Seat", "Mercedes"};
		
		//Listado de modelos
		String modelo[] = {"CX5", "CX5", "Focus", "Ateca", "Clase A"};
		
		//Listado de colores
		String color[] = {"Rojo", "Rojo", "Negro", "Blanco", "Gris"};
		
		//Listado de matriculas
		String matricula[] = {"0909PPX", "1980MLF", "6765BAD", "1188NXS", "9234XCS"};
		
		//Listado de nif de titular
		String nifTitular[] = {"77722888R", "34888874L", "98989274R", "77723788M", "73342119M"};

		//Listado de fechas de matricula
		String fechaMatriculacion[] = {"06/01/2018", "09/08/2001", "03/08/1990", "19/09/2016", "06/06/2018"};
		
		//Listamos.
		fflyweight.listarCoches(marca, modelo, color, matricula, nifTitular, fechaMatriculacion);
		

	}
}


