package PatronFlyweight;

import java.sql.Date;

public class Coche implements IVehiculo {
	public String marca;
	public String modelo;
	public String color;
	public String matricula;
	public String nifTitular;
	public String fechaMatriculacion;
	
	//Constructor Coche, para crear un nuevo coche
	public Coche (String marca, String modelo, String color, String matricula, String nifTitular, String fechaMatriculacion)
	{
		this.marca= marca;
		this.modelo= modelo;
		this.color= color;
		this.matricula= matricula;
		this.nifTitular= nifTitular;
		this.fechaMatriculacion= fechaMatriculacion;
	}
	
	@Override
	public String mostrarDetalle() {
		// Sobrescribimos el mÈtodo para mostrar los detalles que nos interesan.
		return "\n   Marca: " + this.marca + "\n   Modelo: " + this.modelo + "\n   Color: " + this.color + "\n Matricula: " +this.matricula + "\n NifTitular: "
		+ this.nifTitular + "\n Fecha de Matricula: "+ this.fechaMatriculacion +"\n";
	}
	
}
