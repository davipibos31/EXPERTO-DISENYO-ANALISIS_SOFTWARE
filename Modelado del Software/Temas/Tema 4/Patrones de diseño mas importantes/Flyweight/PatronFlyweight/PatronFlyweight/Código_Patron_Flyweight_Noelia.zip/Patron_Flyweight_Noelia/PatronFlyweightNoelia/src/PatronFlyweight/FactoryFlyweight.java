package PatronFlyweight;

import java.sql.Date;

public class FactoryFlyweight {
	IVehiculo coche;
	
	public void listarCoches(String marca[], String modelo[], String color[], String [] matricula, String [] nifTitular, String [] fechaMatriculacion)
	{
		for (int i=0; i < matricula.length; i++)
		{
			coche = new Coche(marca[i], modelo[i], color[i], matricula[i], nifTitular[i], fechaMatriculacion[i]);
			System.out.println("Datos del coche:\n" + coche.mostrarDetalle());
		}
	}
}
