package PatronFlyweight;

//Interfaz IsVehiculo.
public interface IVehiculo {

	public String mostrarDetalle();

}

