package interfaceImprimible;

public interface Imprimible {
	public void imprimir(String texto);
}
