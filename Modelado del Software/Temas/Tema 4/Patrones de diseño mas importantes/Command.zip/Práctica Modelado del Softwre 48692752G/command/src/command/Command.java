package command;
 public interface Command {
     public void ejecutar(int n1, int n2);
}