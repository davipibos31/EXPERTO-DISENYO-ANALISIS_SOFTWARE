package codigo_patron.patron;


public interface Observador {
    public void actualizar(Evento event);
}
