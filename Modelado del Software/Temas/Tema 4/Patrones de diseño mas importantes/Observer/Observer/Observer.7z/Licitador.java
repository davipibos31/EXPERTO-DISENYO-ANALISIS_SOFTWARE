package codigo_patron;


import codigo_patron.patron.Evento;
import codigo_patron.patron.Observador;

/**
 * Jorge Corralo
 */
public class Licitador implements Observador {

    private static int ID = 0;

    @Override
    public void actualizar(Evento event) {
        System.out.println(
                "Identificador: " + (++ID) +
                        ", Evento actualizado: " +  event.getTipo() +
                        ", Descripción evento: " + event.getDescripcion());
    }
}
