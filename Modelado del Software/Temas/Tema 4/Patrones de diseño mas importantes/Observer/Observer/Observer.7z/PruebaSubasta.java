package codigo_patron;


import codigo_patron.patron.Evento;
import codigo_patron.patron.Observador;
import codigo_patron.patron.Sujeto;

/**
 * Jorge Corralo
 */
public class PruebaSubasta {

    public static void main(String[] args) {

        Sujeto subastador = new Subastador();

        Observador licitador1 = new Licitador();
        Observador licitador2 = new Licitador();
        Observador licitador3 = new Licitador();

        subastador.agregar(0, licitador1);
        subastador.agregar(0, licitador2);
        subastador.agregar(0, licitador3);

        subastador.agregar(1, licitador3);

        Evento alta = new Evento(0, "Oferta alta");
        Evento baja = new Evento(1, "Oferta baja");

        subastador.notificar(0, alta);
        subastador.notificar(1, baja);

    }
}
