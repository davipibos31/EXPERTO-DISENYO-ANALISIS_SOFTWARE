package codigo_patron.patron;


public class ObservadorConcreto implements Observador {

    private static int ID = 0;

    @Override
    public void actualizar(Evento event) {
        System.out.println(
                "Identificador: " + (++ID) +
                    ", Actualizando evento: " +  event.getTipo() +
                        ", Descripción evento: " + event.getDescripcion());
    }
}
