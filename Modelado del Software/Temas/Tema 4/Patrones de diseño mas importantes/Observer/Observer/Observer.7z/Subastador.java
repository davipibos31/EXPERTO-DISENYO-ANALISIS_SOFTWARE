package codigo_patron;

import codigo_patron.patron.Evento;
import codigo_patron.patron.Observador;
import codigo_patron.patron.Sujeto;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;


public class Subastador extends Sujeto{

    private final HashMap<Integer, LinkedList<Observador>> observers;

    public Subastador(){
        observers = new HashMap();
    }

    private LinkedList<Observador> getList(int type) {
        if (!observers.containsKey(type)) {
            observers.put(type, new LinkedList<Observador>());
        }
        return observers.get(type);
    }

    @Override
    public void agregar(int eventTpye, Observador newObserver) {
        getList(eventTpye).add(newObserver);
    }

    @Override
    public void eliminar(int eventTpye, Observador observer) {
        getList(eventTpye).remove(observer);
    }

    @Override
    public void notificar(int eventTpye, Evento event) {
        if (observers.containsKey(eventTpye)){
            Iterator<Observador> iterator = observers.get(eventTpye).iterator();
            while(iterator.hasNext()){
                iterator.next().actualizar(event);
            }
        }
    }

}
