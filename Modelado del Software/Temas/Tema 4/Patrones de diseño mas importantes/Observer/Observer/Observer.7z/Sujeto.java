package codigo_patron.patron;


public abstract class Sujeto {

    public abstract void agregar(int eventTpye, Observador observer);
    public abstract void eliminar(int eventTpye, Observador observer);
    public abstract void notificar(int eventTpye, Evento event);

}
