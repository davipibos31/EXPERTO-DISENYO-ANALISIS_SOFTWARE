package codigo_patron.patron;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;


public class SujetoConcreto extends Sujeto {

    private final HashMap<Integer, LinkedList<Observador>> observadores;

    public SujetoConcreto(){
        observadores = new HashMap();
    }

    private LinkedList<Observador> getList(int type) {
        if (!observadores.containsKey(type)) {
            observadores.put(type, new LinkedList<Observador>());
        }
        return observadores.get(type);
    }

    @Override
    public void agregar(int eventTpye, Observador newObserver) {
        getList(eventTpye).add(newObserver);
    }

    @Override
    public void eliminar(int eventTpye, Observador observer) {
        getList(eventTpye).remove(observer);
    }

    @Override
    public void notificar(int eventTpye, Evento event) {
        if (observadores.containsKey(eventTpye)){
            Iterator<Observador> iterator = observadores.get(eventTpye).iterator();
            while(iterator.hasNext()){
                iterator.next().actualizar(event);
            }
        }
    }

}
